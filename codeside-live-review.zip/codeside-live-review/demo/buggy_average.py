def average(values):
    return sum(values) / len(values)

print(average([]))