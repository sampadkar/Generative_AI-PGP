const MODEL = "gemini-3.1-flash-live-preview";

export default async function handler(req, res) {
  res.setHeader("Cache-Control", "no-store");

  if (req.method !== "POST") {
    return res.status(405).json({ error: "Use POST." });
  }

  const key = process.env.GEMINI_API_KEY?.trim();
  if (!key) {
    return res.status(500).json({ error: "GEMINI_API_KEY is missing." });
  }

  try {
    const now = Date.now();
    const response = await fetch(
      "https://generativelanguage.googleapis.com/v1beta/auth_tokens",
      {
        method: "POST",
        headers: {
          "x-goog-api-key": key,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          uses: 1,
          expireTime: new Date(now + 1800000).toISOString(),
          newSessionExpireTime: new Date(now + 60000).toISOString()
        })
      }
    );

    const data = await response.json();

    if (!response.ok) {
      const reason = String(data.error?.message || "Unknown Google error")
        .replaceAll(key, "[REDACTED]");

      console.error("Google token error:", response.status, reason);
      return res.status(502).json({
        error: `Google HTTP ${response.status}`,
        ...(process.env.NODE_ENV === "production" ? {} : { details: reason })
      });
    }

    if (!data.name) {
      throw new Error("Google returned no token.");
    }

    return res.status(200).json({ token: data.name, model: MODEL });
  } catch (error) {
    console.error("Backend error:", error);
    return res.status(502).json({ error: "Could not request a token." });
  }
}