class PcmWorklet extends AudioWorkletProcessor {
  constructor() {
    super();
    this.position = 0;
    this.nextSample = 0;
    this.chunk = new Int16Array(1600);
    this.count = 0;
  }

  process(inputs, outputs) {
    const samples = inputs[0]?.[0];

    if (samples) {
      const ratio = sampleRate / 16000;
      const end = this.position + samples.length;

      while (this.nextSample < end) {
        const sample = Math.max(
          -1,
          Math.min(1, samples[Math.floor(this.nextSample - this.position)])
        );

        this.chunk[this.count++] = sample < 0
          ? Math.round(sample * 32768)
          : Math.round(sample * 32767);

        this.nextSample += ratio;

        if (this.count === this.chunk.length) {
          this.port.postMessage(this.chunk.buffer, [this.chunk.buffer]);
          this.chunk = new Int16Array(1600);
          this.count = 0;
        }
      }

      this.position = end;
    }

    for (const output of outputs) {
      for (const channel of output) channel.fill(0);
    }

    return true;
  }
}

registerProcessor("pcm-worklet", PcmWorklet);