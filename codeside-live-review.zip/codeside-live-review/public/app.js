// CodeSide: raw Gemini Live WebSocket + browser microphone and screen capture.
const endpoint = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContentConstrained";
const instruction = `You are a thoughtful senior engineer reviewing a developer's shared editor while listening to their explanation. Keep spoken responses short (1-3 sentences). Explain what you can actually see; if the code is unreadable, ask them to zoom in. Ask one focused diagnostic question if needed. Prefer the smallest fix and a concrete test. Never claim to have run code, inspected other files, or proved a fix. Avoid interrupting every pause.`;

const els = Object.fromEntries([
  "startButton", "muteButton", "preview", "previewEmpty", "shareLabel",
  "messages", "notice", "status", "badge", "textForm", "textInput", "sendText"
].map((id) => [id, document.getElementById(id)]));

let active = false;
let ready = false;
let socket;
let displayStream;
let micStream;
let audioContext;
let micSource;
let micProcessor;
let videoTimer;
let nextPlayTime = 0;
const playing = new Set();
const frameCanvas = document.createElement("canvas");
const frameContext = frameCanvas.getContext("2d", { alpha: false });
let userBubble = null;
let modelBubble = null;

function setStatus(label, live = false) {
  els.status.textContent = label;
  els.badge.classList.toggle("live", live);
}

function showError(message) {
  els.notice.textContent = message;
  els.notice.style.color = "#b3374e";
}

function bytesToBase64(bytes) {
  let binary = "";
  for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
}

function send(payload) {
  if (socket?.readyState === WebSocket.OPEN && ready) {
    socket.send(JSON.stringify(payload));
  }
}

function appendCaption(role, text) {
  if (!text?.trim()) return;
  const current = role === "You" ? userBubble : modelBubble;
  if (current) {
    current.lastElementChild.textContent += text;
  } else {
    const empty = els.messages.querySelector(".empty-chat");
    if (empty) empty.remove();
    const bubble = document.createElement("div");
    bubble.className = `bubble ${role === "You" ? "user" : "model"}`;
    const label = document.createElement("b");
    label.textContent = role;
    const words = document.createElement("span");
    words.textContent = text;
    bubble.append(label, words);
    els.messages.append(bubble);
    if (role === "You") userBubble = bubble;
    else modelBubble = bubble;
  }
  els.messages.scrollTop = els.messages.scrollHeight;
}

function stopPlayback() {
  for (const source of playing) {
    try { source.stop(); } catch { /* Already completed. */ }
  }
  playing.clear();
  nextPlayTime = 0;
}

function playPcm24k(base64) {
  if (!audioContext || !active) return;
  const raw = atob(base64);
  const bytes = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) bytes[i] = raw.charCodeAt(i);
  const sampleCount = Math.floor(bytes.byteLength / 2);
  if (!sampleCount) return;
  const view = new DataView(bytes.buffer);
  const audio = audioContext.createBuffer(1, sampleCount, 24000);
  const channel = audio.getChannelData(0);
  for (let i = 0; i < sampleCount; i++) channel[i] = view.getInt16(i * 2, true) / 32768;
  const source = audioContext.createBufferSource();
  source.buffer = audio;
  source.connect(audioContext.destination);
  const startAt = Math.max(audioContext.currentTime + 0.04, nextPlayTime);
  source.start(startAt);
  nextPlayTime = startAt + audio.duration;
  source.onended = () => playing.delete(source);
  playing.add(source);
}

async function handleMessage(event) {
  let message;
  try { message = JSON.parse(typeof event.data === "string" ? event.data : await event.data.text()); }
  catch { return; }

  if (message.setupComplete) {
    ready = true;
    setStatus("Live review", true);
    els.notice.style.color = "";
    els.notice.textContent = "Speak naturally. Screen frames are sent at most once per second.";
    els.muteButton.disabled = false;
    els.textInput.disabled = false;
    els.sendText.disabled = false;
    startMicrophone();
    sendFrame();
    videoTimer = setInterval(sendFrame, 1000);
  }

  const content = message.serverContent;
  if (!content) return;
  if (content.interrupted) stopPlayback();
  if (content.inputTranscription?.text) appendCaption("You", content.inputTranscription.text);
  if (content.outputTranscription?.text) appendCaption("CodeSide", content.outputTranscription.text);

  for (const part of content.modelTurn?.parts || []) {
    if (part.inlineData?.mimeType?.startsWith("audio/pcm") && part.inlineData.data) {
      playPcm24k(part.inlineData.data);
    }
  }

  if (content.turnComplete) {
    userBubble = null;
    modelBubble = null;
  }
}

function sendFrame() {
  const video = els.preview;
  if (!ready || !active || video.readyState < 2 || !video.videoWidth || !frameContext) return;
  const scale = Math.min(1, 1600 / video.videoWidth);
  frameCanvas.width = Math.round(video.videoWidth * scale);
  frameCanvas.height = Math.round(video.videoHeight * scale);
  frameContext.drawImage(video, 0, 0, frameCanvas.width, frameCanvas.height);
  const image = frameCanvas.toDataURL("image/jpeg", 0.88).split(",")[1];
  send({ realtimeInput: { video: { mimeType: "image/jpeg", data: image } } });
}

function startMicrophone() {
  micSource = audioContext.createMediaStreamSource(micStream);
  micProcessor = new AudioWorkletNode(audioContext, "pcm-worklet");
  micProcessor.port.onmessage = ({ data }) => {
    if (!ready || !active || !micStream.getAudioTracks()[0]?.enabled) return;
    send({ realtimeInput: {
      audio: { mimeType: "audio/pcm;rate=16000", data: bytesToBase64(new Uint8Array(data)) }
    } });
  };
  micSource.connect(micProcessor).connect(audioContext.destination);
}

async function startReview() {
  els.startButton.disabled = true;
  els.notice.style.color = "";
  setStatus("Requesting access");

  try {
    if (!navigator.mediaDevices?.getDisplayMedia || !navigator.mediaDevices?.getUserMedia) {
      throw new Error("Use a current desktop browser on localhost or HTTPS.");
    }

    const displayPromise = navigator.mediaDevices.getDisplayMedia({ video: true, audio: false });
    audioContext = new AudioContext();
    const audioReady = audioContext.resume();
    displayStream = await displayPromise;
    await audioReady;

    displayStream.getVideoTracks()[0].addEventListener("ended", () => {
      if (active) stopReview("Screen sharing stopped.");
    });

    els.preview.srcObject = displayStream;
    await els.preview.play();
    els.preview.style.display = "block";
    els.previewEmpty.style.display = "none";
    els.shareLabel.textContent = "Window sharing";

    micStream = await navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: true, noiseSuppression: true, channelCount: 1 }
    });
    await audioContext.audioWorklet.addModule("/audio-worklet.js");

    setStatus("Connecting");
    const response = await fetch("/api/token", { method: "POST", cache: "no-store" });
    const auth = await response.json();
    if (!response.ok) throw new Error(auth.error || "Could not get a session token.");

    active = true;
    socket = new WebSocket(`${endpoint}?access_token=${encodeURIComponent(auth.token)}`);

    socket.onopen = () => {
      socket.send(JSON.stringify({ setup: {
        model: `models/${auth.model}`,
        responseModalities: ["AUDIO"],
        inputAudioTranscription: {},
        outputAudioTranscription: {},
        contextWindowCompression: { slidingWindow: {} },
        systemInstruction: { parts: [{ text: instruction }] }
      } }));
    };

    socket.onmessage = (event) => {
      handleMessage(event).catch((error) => showError(error.message));
    };
    socket.onerror = () => showError("Live connection failed. Check your key, model access, and network.");
    socket.onclose = () => {
      if (active) stopReview("Connection ended. Click Start review to reconnect.");
    };

    els.startButton.textContent = "End review";
    els.startButton.disabled = false;
  } catch (error) {
    stopReview(error.name === "NotAllowedError"
      ? "Screen or microphone permission was denied."
      : error.message);
  }
}

function stopReview(message = "Review ended. Your screen and microphone have stopped sharing.") {
  active = false;
  ready = false;
  clearInterval(videoTimer);
  videoTimer = null;
  stopPlayback();

  if (socket) {
    socket.onclose = null;
    socket.close();
    socket = null;
  }

  micProcessor?.disconnect();
  micSource?.disconnect();
  micProcessor = null;
  micSource = null;

  displayStream?.getTracks().forEach((track) => track.stop());
  micStream?.getTracks().forEach((track) => track.stop());
  displayStream = null;
  micStream = null;

  audioContext?.close().catch(() => {});
  audioContext = null;

  els.preview.srcObject = null;
  els.preview.style.display = "none";
  els.previewEmpty.style.display = "block";
  els.shareLabel.textContent = "Not sharing";
  els.startButton.textContent = "Start review";
  els.startButton.disabled = false;
  els.muteButton.textContent = "Mute mic";
  els.muteButton.disabled = true;
  els.textInput.disabled = true;
  els.sendText.disabled = true;
  els.notice.textContent = message;
  setStatus("Ready");
  userBubble = null;
  modelBubble = null;
}

els.startButton.addEventListener("click", () => active ? stopReview() : startReview());

els.muteButton.addEventListener("click", () => {
  const track = micStream?.getAudioTracks()[0];
  if (!track) return;
  track.enabled = !track.enabled;
  els.muteButton.textContent = track.enabled ? "Mute mic" : "Unmute mic";
  if (!track.enabled) send({ realtimeInput: { audioStreamEnd: true } });
});

els.textForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const value = els.textInput.value.trim();
  if (!value || !ready) return;
  appendCaption("You", value);
  userBubble = null;
  send({ realtimeInput: { text: value } });
  els.textInput.value = "";
});

window.addEventListener("pagehide", () => {
  if (active) stopReview();
});