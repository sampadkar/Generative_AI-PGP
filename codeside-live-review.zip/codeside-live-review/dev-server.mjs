// Local development server for the website and token endpoint.
import http from "node:http";
import { readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { dirname, extname, join, normalize } from "node:path";
import tokenHandler from "./api/token.js";

const root = dirname(fileURLToPath(import.meta.url));

try {
  const env = await readFile(join(root, ".env.local"), "utf8");

  for (const line of env.split(/\r?\n/)) {
    const match = line.match(/^\s*GEMINI_API_KEY\s*=\s*(.+?)\s*$/);

    if (match && !process.env.GEMINI_API_KEY) {
      process.env.GEMINI_API_KEY = match[1].replace(/^['"]|['"]$/g, "");
    }
  }
} catch {
  // The environment variable may already be set.
}

const contentTypes = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".svg": "image/svg+xml"
};

http.createServer(async (req, res) => {
  res.status = (code) => {
    res.statusCode = code;
    return res;
  };

  res.json = (value) => {
    res.setHeader("Content-Type", "application/json");
    res.end(JSON.stringify(value));
  };

  if (req.url === "/api/token") {
    return tokenHandler(req, res);
  }

  const pathname = new URL(req.url, "http://localhost").pathname;
  const relative = pathname === "/"
    ? "index.html"
    : pathname.replace(/^\/+/, "");

  const safe = normalize(relative);

  if (safe.startsWith("..") || safe.includes("\\")) {
    res.writeHead(403);
    return res.end("Forbidden");
  }

  try {
    const bytes = await readFile(join(root, "public", safe));

    res.writeHead(200, {
      "Content-Type": contentTypes[extname(safe)] || "application/octet-stream"
    });

    res.end(bytes);
  } catch {
    res.writeHead(404);
    res.end("Not found");
  }
}).listen(3000, () => {
  console.log("CodeSide at http://localhost:3000");
});