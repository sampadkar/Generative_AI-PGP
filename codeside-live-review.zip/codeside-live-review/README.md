# CodeSide — Live Code Review Companion

CodeSide lets a developer share an editor window, explain a bug aloud, and receive short spoken guidance based on the visible code. It is built for the NSOffice internship assignment.

## Technology

- HTML and CSS for the interface
- Browser JavaScript for screen sharing, microphone capture, transcripts, and audio playback
- Node.js for the local server and the private token endpoint
- Gemini Live API: gemini-3.1-flash-live-preview
- Vercel for deployment

## Requirements

- Node.js 20 or newer
- Chrome or Edge
- A Gemini API key with access to the assignment's Live model

## Environment variable

Create `.env.local` in the project root:

    GEMINI_API_KEY=your_key_here

Keep this file private. On Vercel, add `GEMINI_API_KEY` under the project's Environment Variables instead.

## Run locally

On Windows PowerShell, from the project folder:

    npm.cmd run check
    npm.cmd run dev

Open http://localhost:3000.

## Try the demo

1. Open `demo/buggy_average.py` in VS Code and enlarge the editor text.
2. On CodeSide, click **Start review**.
3. Select the VS Code window and allow microphone access.
4. Say: "This crashes when the list is empty. Can you see why?"
5. Listen to the reply, then click **End review**.

## How it works

The browser captures the selected window and microphone. The Node.js token endpoint uses the private API key to request a short-lived Gemini token. The browser then connects to Gemini Live and sends microphone audio and screen frames. Spoken responses play in the browser.

The app does not execute the shared code or inspect files that are not visible on screen. The displayed transcript is not saved by this app.

## Deployment

Push this project to a public GitHub repository. Import the repository into Vercel, add `GEMINI_API_KEY` as a private environment variable, deploy, and test the public HTTPS URL.

The assignment refers to an emailed NSOffice skill folder containing `tokens.css` and `liquid-glass.js`. Apply those supplied assets when available.